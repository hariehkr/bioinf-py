function handleAuthSubmit(actionContextType) {
    if(actionContextType === 'Login') {
        // Post message payload directly up to parent pipeline architecture
        window.parent.postMessage('AUTH_SUCCESS_DISPATCH', '*');
    } else {
        alert(`Authentication Engine Action Triggered: Processing [${actionContextType}] Request.`);
    }
}